library(testthat)
library(PermFDATest)

test_check("PermFDATest")
