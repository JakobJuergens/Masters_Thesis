test_that("Cramer-von Mises Test works", {
  expect_equal(2 * 2, 5)
})
