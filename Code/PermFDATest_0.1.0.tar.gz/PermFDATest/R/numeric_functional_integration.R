monte_carlo_integration <- function(test_func, n_points, sample1, sample2){

}
