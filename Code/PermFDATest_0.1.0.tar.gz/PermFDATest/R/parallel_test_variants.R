#' This function is aimed at the application for my master's thesis and is
#' experimental. It performs the approximation means based test parallelized
#' over the permutations.
#'
#' @param cl: cluster object created by parallel package
