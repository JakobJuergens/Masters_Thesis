#' This function calculates the means of the fourier coefficients as described
#' in section 5 of Bugni, Horowitz (2021) for a chosen basis and a function  w
#'
#' @param w_func: function that is large in the areas of the domain the
#' investigator expects differences in the distribution functions
#' @param basis: type of functional basis to use (has to be an orthogonal basis)
#' @param n_basis: number of basis functions
#' @param domain: vector of two points (start and endpoint of the closed interval)
#'
#' @return: Vector of length n_basis containing the resulting means of the
#' fourier coefficients
fourier_basis_coef_means <- function(w_func, basis = "fourier", n_basis, domain = c(0, 1)) {
  # create chosen basis (has to be orthogonal basis!)
  if (basis == "fourier") {
    my_basis <- fda::create.fourier.basis(
      rangeval = domain, nbasis = n_basis)
  } else {
    stop("Chosen basis not implemented.")
  }
  # extract basis functions as function objects
  basis_functions <- purrr::map(
    .x = 1:n_basis,
    .f = function(i) {
      basis_func <- function(x) {
        fda::eval.basis(evalarg = x, basisobj = my_basis)[1, i]
      }
    }
  )
  # calculate means of fourier coefficients
  coef_means <- purrr::map(
    .x = basis_functions,
    .f = function(f) {
      fourier_coef_mean(w_func = w_func, basis_func = f, domain = domain)
    }
  )
  # return vector of means of fourier coefficients
  return(unlist(coef_means))
}

#' This function calculates the desired mean of a fourier coefficient for
#' a single basis function
#'
#' @param w_func: function that is large in the areas of the domain the
#' investigator expects differences in the distribution functions
#' @param basis_func: basis function to calculate the fourier coefficient for
#' @param domain: vector of two points (start and endpoint of the closed interval)
#'
#' @return: Double that is the desired mean of the fourier coefficient
fourier_coef_mean <- function(w_func, basis_func, domain = c(0, 1)) {
  # define function to integrate over
  prod_func <- Vectorize(FUN = function(x) {
    return(w_func(x) * basis_func(x))
  })
  # integrate over product function
  coef_mean <- integrate(f = prod_func, lower = domain[1], upper = domain[2])$value
  # return appropriate mean object
  return(coef_mean)
}

#' This function samples a desired distribution of fourier coefficients
#' around a mean that's determined by the function w
#'
#' @param w_func: function that is large in the areas of the domain the
#' investigator expects differences in the distribution functions
#' @param basis: type of functional basis to use (has to be an orthogonal basis)
#' @param n_basis: number of basis functions
#' @param domain: vector of two points (start and endpoint of the closed interval)
#' @param u_sample_func: function that can be used to sample from for the error terms
#' around the specified mean
#' @param ...: further parameters that are given to u_sample_func
#'
#' @return: A vector of length n_basis of sampled fourier coefficients
fourier_coef_sample <- function(w_func, basis = "fourier", n_basis,
                                u_sample_func, domain = c(0, 1), ...) {
  # calculate means of fourier coefficients
  means <- fourier_basis_coef_means(
    w_func = w_func, basis = basis,
    n_basis = n_basis, domain = domain
  )
  # one example for u_sample_func
  # function(n){MASS::mvrnorm(n = n, mu = rep(0, 15), Sigma = diag(rep(1, times = 15)))}

  # realizations of the fourier coefficients
  realizations <- means + u_sample_func(n_basis = n_basis, ...)
  # return realizations
  return(realizations)
}

#' This function is used to draw the rho coefficients used in the construction
#' of the mu measure as described in the paper. These have to falls into l2
#' However, it is often advisable to specify these yourself.
#'
rho_draw <- function(n_basis, coef_vector = NULL){
  if(!is.null(coef_vector) & length(coef_vector) == n_basis){
    return(coef_vector)
  }

  # otherwise generate entries from a square summable sequence
  else{

  }
}
