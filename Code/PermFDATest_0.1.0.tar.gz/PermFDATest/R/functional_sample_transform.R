#' This function transforms a sample of functional data as it is typically generated
#' by functions from the package fda into the format that is used for example
#' for the function empirical_dist_func
#'
#' @param original_sample:
#'
func_sample_transform <- function(){

}
